name="MFU China AI - Unchanged China policies"
supported_version="1.19.*"
dependencies={ "MFU-Updated" }
path="mod/MFU_CHI_unchanged"
