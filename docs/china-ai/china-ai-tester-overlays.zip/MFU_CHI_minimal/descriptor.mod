name="MFU China AI - Minimal cautious China"
supported_version="1.19.*"
dependencies={ "MFU-Updated" }
