name="MFU China AI - Full China operations without USA preferences"
supported_version="1.19.*"
dependencies={ "MFU-Updated" }
