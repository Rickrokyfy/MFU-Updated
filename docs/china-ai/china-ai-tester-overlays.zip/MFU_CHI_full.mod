name="MFU China AI - Full China operations and USA preferences"
supported_version="1.19.*"
dependencies={ "MFU-Updated" }
path="mod/MFU_CHI_full"
