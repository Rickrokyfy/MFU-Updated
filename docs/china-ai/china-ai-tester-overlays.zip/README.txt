Comparison overlays only; these do not contain the base mod assets.
Required base: Rickrokyfy/MFU-Updated revision
5c08df3707b3434e9a519ba54942323e93b226eb (includes the 24-tier aircraft reduction).
Base ZIP: https://github.com/Rickrokyfy/MFU-Updated/archive/5c08df3707b3434e9a519ba54942323e93b226eb.zip
Put the base contents directly in mod/MFU-Updated-base and place the supplied
MFU-Updated-base.mod alongside it. The base assets are NOT included here.
Disable other copies of the base mod in the test playset.
Copy the desired MFU_CHI_<mode> folder and matching .mod file into your own
HOI4 user-directory mod folder. Enable MFU-Updated and exactly ONE overlay
in a dedicated launcher playset; ensure the overlay loads after MFU-Updated.
Full (with USA preferences) is the reference/default mode; no mode is selected
automatically by extracting this archive. Choose one explicitly.
Do not enable multiple overlays or combine with other overhaul/AI mods.
unchanged = pre-China-prototype policies, with the aircraft reduction retained.
minimal = prior manual-only cautious opportunity prototype.
full_no_usa = operation cycle without USA preferences.
full = operation cycle plus human-USA preferences.
These are local test artifacts, not a published mod or tested launcher recipe.
Check the in-game checksum, version, actual loaded files and startup errors.
Use fresh campaigns for between-mode comparisons; save/reload checks should
stay within the same mode. See TESTER_BRIEF.md for conditions and measurements.
